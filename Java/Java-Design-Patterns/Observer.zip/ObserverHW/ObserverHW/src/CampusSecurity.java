import java.util.ArrayList;

public class CampusSecurity implements Subject{
	private ArrayList<Observer> Observers;
	private String weatherData;
	private String nationalAlert;
	private String campusAlert;
	
	CampusSecurity() {
		Observers = new ArrayList<Observer>();
	}
	
	@Override
	public void Attach(Observer o) {
		// TODO Auto-generated method stub
		Observers.add(o);
	}

	@Override
	public void Detach(Observer o) {
		// TODO Auto-generated method stub
		int x = Observers.indexOf(o);
		if(x >= 0) { Observers.remove(x);}
	}

	@Override
	public void alertsChanged() {
		// TODO Auto-generated method stub
		for(int i = 0; i < Observers.size(); i++) {
			Observer observer = (Observer)Observers.get(i);
			observer.Update(weatherData, nationalAlert, campusAlert);
		}
	}
	
	public void setAlerts(String newWeather, String newNational, String newCampus) {
		this.weatherData = newWeather;
		this.nationalAlert = newNational;
		this.campusAlert = newCampus;
		alertsChanged();
	}
	
	public String getWeatherdata() {
		return weatherData;
	}
	
	public String getNationalAlert() {
		return nationalAlert;
	}
	
	public String getCampusAlert() {
		return campusAlert;
	}
}
