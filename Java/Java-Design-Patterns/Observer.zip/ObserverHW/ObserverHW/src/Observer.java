
public interface Observer {

	public abstract void Update(String weatherData, String nationalAlert, String campusAlert);
}
