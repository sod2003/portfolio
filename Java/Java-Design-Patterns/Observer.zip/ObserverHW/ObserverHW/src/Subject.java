
public interface Subject {

	public abstract void Attach(Observer o);
	
	public abstract void Detach(Observer o);
	
	public abstract void alertsChanged();
}
