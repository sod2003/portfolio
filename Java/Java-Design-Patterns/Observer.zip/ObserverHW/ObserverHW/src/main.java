
public class main {
	
	public static void main(String[] args) {
	CampusSecurity campus = new CampusSecurity();
	Terminal terminal = new Terminal(campus);
	campus.setAlerts("Sunny", "Threat Level: High", "East Parking Deck closed until July 4th.");
	campus.Detach(terminal);
	campus.setAlerts("Sunny partly cloudy", "Threat Level: Highish", "East Parking Deck closed until after July 4th.");
	}
}
