
public class Terminal implements Observer{
	private Subject campusSecurity;
	private String weatherData;
	private String nationalAlert;
	private String campusAlert;
	
	Terminal(Subject subject) {
		this.campusSecurity = subject;
		subject.Attach(this);
	}
	
	@Override
	public void Update(String weatherData, String nationalAlert, String campusAlert) {
		// TODO Auto-generated method stub
		this.weatherData = weatherData;
		System.out.println("New weather Alert: " + weatherData);
		this.nationalAlert = nationalAlert;
		System.out.println("New National Alert: " + nationalAlert);
		this.campusAlert = campusAlert;
		System.out.println("New Campus Alert: " + campusAlert);
	}

}
